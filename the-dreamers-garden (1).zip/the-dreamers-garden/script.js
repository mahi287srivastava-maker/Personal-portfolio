const poems = [
  {
    title: "On This Note, I Let My Hair Back",
    theme: "A poem about becoming",
    category: "self",
    text: `there's a corner of my room,
untouched ,
still and the wind dare not caress it's head,
my curiosity gravitates me ,
like the aroma of my beloved does.

I hold my breath as i always do,
and count to ten so i breathe much loose,
my greatest phobia was to dare,
and regret shall not repair like a broken glass.

one step closer,I gently put my feet ,
and let my fear fly away, like an uncaged bird.

sitting there in silence,
is a dusted brown box ,old enough to have wrinkles on it's face ,
but,fear is bad and it shall fade,
I lean a bit forward and sway it open straight .

How had i not done this before,
it holds not just a potrait ,
but a version of me i would die to grow,
the hair shaped in curves like waves of the sea,
i thought this is the confidence i would need.

I am older and wiser as I should be,
but sometimes you should hear yourself,
as no voice is deeper than your soul,
not even the cuckoo's dawnlight song to sleep.
on this note , i let my hair back.`
  },
  {
    title: "Of Gods, Dreams & Ashes",
    theme: "A poem about ambition",
    category: "myth",
    text: `She raised her voice just once,
so softly the sky mistook it for a prayer
Yet Zeus must have heard her trembling cry.
A pale light unfurled around her,
gentler than the cuckoo's dawnlight,
and Apollo then spread his warm golden wings,
and drew her close enough to shield her.

For the first time,safety wrapped itself around her ribs,
A heart once hammered into iron,
began to glow like softened gold.
She dreamed of walking beside Jason,
To claim,this time, a platinum fleece.

But how greed has pulled millions down,
and dreams that shine might cut too deep,
Like once Icarus fell from the sky.

In her own rising fire,she burned her-self,
And the dreams enclosed in her ashes,
whispered Daedalus behind her back.
She did pause and then gathered the pieces from the fire.`
  },
  {
    title: "Between Time & Becoming",
    theme: "A poem about uncertainty",
    category: "time",
    text: `As time passes by,
The days flow like a river stream,
The transition from childhood to adult,
Feels nothing short of an unattainable dream.

I promise myself to give my best,
But my brain says a thing-
Which my heart does not believe
Is my brain right or my pouncing heart,
Maybe its my faith or the question of time?

Like the oceans waves,I strive and bend,
to conquer every situation to the best I can,
I try to summon all the strength each day,
But still,will I fail or find my way?`
  }
];

const lines = [
  "You are allowed to grow at your own pace.",
  "Even the smallest seed begins beneath the soil.",
  "You can be a work in progress and still be worthy.",
  "Some doors open only when you stop being afraid to knock.",
  "There is courage in beginning again, quietly.",
  "Let the version of you that dreams meet the one that tries."
];

const menuToggle = document.getElementById("menuToggle");
const navLinks = document.getElementById("navLinks");
const modal = document.getElementById("poemModal");
const modalTitle = document.getElementById("modalTitle");
const modalTheme = document.getElementById("modalTheme");
const modalPoem = document.getElementById("modalPoem");
const savePoem = document.getElementById("savePoem");
const saveNote = document.getElementById("saveNote");
let activePoem = 0;

menuToggle.addEventListener("click", () => {
  const isOpen = navLinks.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", String(isOpen));
  menuToggle.setAttribute("aria-label", isOpen ? "Close navigation" : "Open navigation");
  menuToggle.textContent = isOpen ? "×" : "☰";
});

navLinks.querySelectorAll("a").forEach(link => {
  link.addEventListener("click", () => {
    navLinks.classList.remove("open");
    menuToggle.setAttribute("aria-expanded", "false");
    menuToggle.setAttribute("aria-label", "Open navigation");
    menuToggle.textContent = "☰";
  });
});

document.querySelectorAll(".filter-button").forEach(button => {
  button.addEventListener("click", () => {
    document.querySelectorAll(".filter-button").forEach(item => item.classList.remove("active"));
    button.classList.add("active");
    const filter = button.dataset.filter;
    document.querySelectorAll(".poem-card").forEach(card => {
      card.hidden = filter !== "all" && card.dataset.category !== filter;
    });
  });
});

function getSavedPoems() {
  try {
    return JSON.parse(localStorage.getItem("dreamersGardenSaved") || "[]");
  } catch {
    return [];
  }
}

function openPoem(index) {
  activePoem = index;
  const poem = poems[index];
  modalTitle.textContent = poem.title;
  modalTheme.textContent = poem.theme;
  modalPoem.textContent = poem.text;
  saveNote.textContent = "";
  updateSaveButton();
  modal.classList.add("open");
  modal.setAttribute("aria-hidden", "false");
  document.body.style.overflow = "hidden";
  document.getElementById("modalClose").focus();
}

function closePoem() {
  modal.classList.remove("open");
  modal.setAttribute("aria-hidden", "true");
  document.body.style.overflow = "";
}

function updateSaveButton() {
  const saved = getSavedPoems().includes(activePoem);
  savePoem.textContent = saved ? "♥ Saved to your garden" : "♡ Save this poem";
}

document.querySelectorAll(".read-button").forEach(button => {
  button.addEventListener("click", () => openPoem(Number(button.dataset.poem)));
});

document.getElementById("modalClose").addEventListener("click", closePoem);
modal.querySelector(".modal-backdrop").addEventListener("click", closePoem);
document.addEventListener("keydown", event => {
  if (event.key === "Escape" && modal.classList.contains("open")) closePoem();
});

savePoem.addEventListener("click", () => {
  const saved = getSavedPoems();
  const alreadySaved = saved.includes(activePoem);
  const updated = alreadySaved ? saved.filter(index => index !== activePoem) : [...saved, activePoem];
  localStorage.setItem("dreamersGardenSaved", JSON.stringify(updated));
  updateSaveButton();
  saveNote.textContent = alreadySaved ? "Removed from your saved poems." : "Saved in this browser. Come back whenever you like.";
});

document.getElementById("newQuote").addEventListener("click", () => {
  const quoteText = document.getElementById("quoteText");
  let nextLine = quoteText.textContent;
  while (lines.length > 1 && nextLine === quoteText.textContent) {
    nextLine = lines[Math.floor(Math.random() * lines.length)];
  }
  quoteText.textContent = nextLine;
});

document.getElementById("year").textContent = new Date().getFullYear();
