# The Dreamer's Garden

A responsive poetry website for **Between Dreams & Lines**, created as a beginner-friendly frontend project.

## Overview
The Dreamer's Garden is a calm, botanical-inspired digital space for reading poetry and collecting meaningful lines.

## Features
- Pastel botanical design with a custom flower illustration
- Responsive layout for desktop and mobile
- Poetry cards with full poem reading modals
- Theme filters for the poem collection
- Random poetic-line generator
- Save/unsave poems using browser local storage
- Mobile navigation menu
- Keyboard support: press Escape to close a poem

## Technology stack
- HTML5
- CSS3 (Grid, Flexbox, media queries, animations)
- Vanilla JavaScript
- Google Fonts

## Run locally
1. Download or clone this repository.
2. Open the project folder in VS Code.
3. Open `index.html` in your browser, or use the Live Server extension.

No build step, backend, or database is required.

## Deployment with GitHub Pages
1. Push these files to a GitHub repository.
2. Open the repository's **Settings**.
3. Select **Pages** in the sidebar.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch `main` and folder `/ (root)`, then click **Save**.
6. Wait for GitHub Pages to publish the site. The live URL will appear in the Pages section.

## Notes
Poems are displayed as provided by the author. Saved favorites are stored locally in the visitor's browser and are not shared between devices.
